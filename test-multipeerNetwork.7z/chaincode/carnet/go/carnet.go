package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

type SmartContract struct {
}

type Car struct {
	Name       string `json:"name"`
	Maker      string `json:"maker"`
	Model      string `json:"model"`
	Color      string `json:"color"`
	Price      int    `json:"price"`
	Owner      string `json:"owner"`
	Status     string `json:"status"`
}

func main() {
	err := shim.Start(new(SmartContract))
	if err != nil {
		fmt.Printf("Error starting Simple chaincode: %s", err)
	}
}

func (t *SmartContract) Init(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("Init() is running.")
	return shim.Success(nil)
}

func (t *SmartContract) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	function, args := stub.GetFunctionAndParameters()
	fmt.Println("invoke() is running : " + function)

	if function == "initCar" {
		return t.initCar(stub)
	} else if function == "queryAllCars" {
		return t.queryAllCars(stub)
	} else if function == "queryCar" {
		return t.queryCar(stub, args)
	} else if function == "createCar" {
		return t.createCar(stub, args)
	} else if function == "changeCarOwner" {
		return t.changeCarOwner(stub, args)
	} else if function == "registPdfHash" {
		return t.registPdfHash(stub, args)
	} else if function == "getPdfHash" {
		return t.getPdfHash(stub, args)
	}

	fmt.Println("invoke did not find func: " + function) //error
	return shim.Error("Received unknown function invocation")
}

func (t *SmartContract) initCar(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("initCar() is running.")
	//var err error

	cars := []Car{
		Car{Name:"c0", Maker: "Toyota", Model: "Prius", Color:"blue", Price:3500, Owner: "Tomoko", Status: "Ready"},
		Car{Name:"c1", Maker: "Ford", Model: "Mustang", Color:"red", Price:3000, Owner: "Brad", Status: "Ready"},
		Car{Name:"c2", Maker: "Hyundai", Model: "Tucson", Color:"green", Price:2500, Owner: "Jin Soo", Status: "Ready"},
		Car{Name:"c3", Maker: "Volkswagen", Model: "Passat", Color:"yellow", Price:2000, Owner: "Max", Status: "Ready"},
		Car{Name:"c4", Maker: "Tesla", Model: "S", Color:"black", Price:1500, Owner: "Adriana", Status: "Ready"},
		Car{Name:"c5", Maker: "Peugeot", Model: "205", Color:"purple", Price:1000, Owner: "Michel", Status: "Ready"},
		Car{Name:"c6", Maker: "Chery", Model: "S22L", Color:"white", Price:500, Owner: "Aarav", Status: "Ready"},
		Car{Name:"c7", Maker: "Fiat", Model: "Punto", Color:"violet", Price:250, Owner: "Pari", Status: "Ready"},
		Car{Name:"c8", Maker: "Tata", Model: "Nano", Color:"indigo", Price:100, Owner: "Valeria", Status: "Ready"},
		Car{Name:"c9", Maker: "Holden", Model: "Barina", Color:"brown", Price:50, Owner: "Shotaro", Status: "Ready"},
	}

	i := 0
	for i < len(cars) {
		fmt.Println("i is ", i)
		carAsBytes, _ := json.Marshal(cars[i])
		stub.PutState("CAR0"+strconv.Itoa(i), carAsBytes)
		fmt.Println("Added", cars[i])
		i = i + 1
	}

	return shim.Success(nil)
}

func (t *SmartContract) queryAllCars(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("queryAllCars() is running.")

	startKey := "CAR0"
	endKey := "CAR999"

	resultsIterator, err := stub.GetStateByRange(startKey, endKey)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryResults
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}

		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		buffer.WriteString("}")

		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	fmt.Printf("- queryAllCars:\n%s\n", buffer.String())

	return shim.Success(buffer.Bytes())

}

func (t *SmartContract) queryCar(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("queryCar() is running.")

	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	carAsBytes, _ := stub.GetState(args[0])

	return shim.Success(carAsBytes)
}

func (t *SmartContract) createCar(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("createCar() is running.")

	if len(args) != 6 {
		//return shim.Error("Incorrect number of arguments. Expecting 5")
	}

	// ==== Input sanitation ====
	fmt.Println("- start createCar")

	price, err := strconv.Atoi(args[4])
	if err != nil {
		return shim.Error("3rd argument must be a numeric string")
	}

	//existCarAsBytes, _ := stub.GetState(args[0])

	var car = Car{Name:args[0], Maker: args[1], Model: args[2], Color:args[3], Price:price, Owner: args[5], Status: "Ready"}

	carAsBytes, _ := json.Marshal(car)
	fmt.Println("Key = ",  args[0])
	stub.PutState(args[0], carAsBytes)

	fmt.Println("- end createCar")
	return shim.Success(nil)

}

func (t *SmartContract) changeCarOwner(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) != 2 {
		return shim.Error("Incorrect number of arguments. Expecting 2")
	}
	fmt.Println("get => " + args[0])

	carAsBytes, _ := stub.GetState(args[0])
	car := Car{}

	json.Unmarshal(carAsBytes, &car)

	if car.Status == "Ready"{
		car.Owner = args[1]
		car.Status = "Done"
		carAsBytes, _ = json.Marshal(car)
		stub.PutState(args[0], carAsBytes)
	}

	return shim.Success(nil)
}

func (t *SmartContract) registPdfHash(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("registPdfHash() is running.")

	//arg[0] = transaction_id
	//arg[1] = timestamp
	//arg[2] = msg
	if len(args) != 3 {
		return shim.Error("Incorrect number of arguments. Expecting 3")
	}

	// ==== Input sanitation ====
	fmt.Println("- start registPdfHash")
	fmt.Println("- Parameters: Key= ",  args[0] ," timestamp= ",  args[1] ," msg= ",  args[2])

	var car = Car{Name:args[1], Maker: args[2], Model: "", Color:"", Price:0, Owner: "", Status: ""}

	carAsBytes, _ := json.Marshal(car)
	fmt.Println("Key = ",  args[0])
	stub.PutState(args[0], carAsBytes)

	fmt.Println("- end registPdfHash")
	return shim.Success(nil)
}

func (t *SmartContract) getPdfHash(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("getPdfHash() is running.")

	//arg[0] = transaction_id
	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}
	fmt.Println("- start getPdfHash")
	fmt.Println("- Parameters: Key= ",  args[0])

	carAsBytes, _ := stub.GetState(args[0])

	fmt.Println("- end getPdfHash")
	return shim.Success(carAsBytes)
}

