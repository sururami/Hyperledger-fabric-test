package main

import (
	"fmt"
	"strconv"
	
	"github.com/hyperledger/fabric/common/util"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

type SmartContract struct {
}

func main() {
	err := shim.Start(new(SmartContract))
	if err != nil {
		fmt.Printf("Error starting Simple chaincode: %s", err)
	}
}

func (t *SmartContract) Init(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("Init() is running.")
	return shim.Success(nil)
}

func (t *SmartContract) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	function, args := stub.GetFunctionAndParameters()
	fmt.Println("invoke() is running : " + function)

	chaincodeURL := "github.com/hyperledger/fabric-samples/chaincode/carnet/go"

	functionArgs := util.ToChaincodeArgs(function)

	response := stub.InvokeChaincode(chaincodeURL, functionArgs, "")

	fmt.Println("invoke did not find func: " + function) //error
	return shim.Error("Received unknown function invocation")
}

func (t *SmartContract) queryCar(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	fmt.Println("queryCar() is running.")

	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	carAsBytes, _ := stub.GetState(args[0])

	return shim.Success(carAsBytes)
}